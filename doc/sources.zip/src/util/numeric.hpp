#ifndef numeric_hpp
#define numeric_hpp

/** This is the root class of numeric utility classes and factories. */
class numeric {};

#endif
