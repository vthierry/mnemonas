#ifndef __s_string__
#define __s_string__

#include <string>

/** Defines a string constant value. */
typedef const std::string& String;

#endif
