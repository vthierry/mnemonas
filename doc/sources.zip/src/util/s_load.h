#include "s_string.h"

/** Loads a string from a file.
 * @param file The file name.
 */
std::string s_load(String file);
