///@cond INTERNAL

void ParameterOptimizer_test()
{
  ParameterOptimizer o("{'mode'  : ['true', 'false'], 'scale' : [0.1, 0.2, 0.5, 1, 2, 5, 10]}");
}
///@endcond
